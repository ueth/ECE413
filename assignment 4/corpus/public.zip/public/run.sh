#!/bin/bash

export FLASK_DEBUG="FALSE"

rm -rf ./flask-sessions

python3 app/app.py 


